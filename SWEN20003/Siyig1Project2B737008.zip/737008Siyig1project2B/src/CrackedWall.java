
public class CrackedWall extends Tile{
	/**
	 * CLass created for cracked wall sprite
	 */
	
	/**
	 * Constructor for the Cracked Wall
	 * @param image_src the image file
	 * @param csvX the coordinate from map file
	 * @param csvY the coordinate from map file
	 */
	public CrackedWall(String image_src, int csvX, int csvY) {
		super(image_src, csvX, csvY);
	}
	
	/*saved for future extension as well as help logically thinking*/
}
